/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var jpdbBaseURL="http://api.login2explore.com:5577";
var jpdbIRL= "/api/irl";
var jpdbIML= "/api/iml";
var proDBName="COLLEGE-DB";
var proRelationName="PROJECT-TABLE";
var connToken="90938336|-31949271899136568|90952433";

$('#proid').focus();

function saveRecNo2LS(jsonObj)
{
    var lvData=JSON.parse(jsonObj.data);
    localStorage.setItem('recno',lvData.rec_no);
}

function getProIdAsJsonObj()
{
    var proid=$('#proid').val();
    var jsonStr=
            {
                id:proid
    };
    return JSON.stringify(jsonStr);
}

function fillData(jsonObj)
{
    saveRecNo2LS(jsonObj);
    var record=JSON.parse(jsonObj.data).record;
    $('#proname').val(record.name);
     $('#proassignedto').val(record.assignedto);
      $('assignmentdate').val(record.assignmentdate);
       $('#deadline').val(record.deadline);
        }
    
function resetForm()
{
    $('#proid').val('');
     $('#proname').val('');
     $('#proassignedto').val('');
      $('#assignmentdate').val('');
       $('#deadline').val('');
        $('#proid').prop("",false);
        $('#save').prop("",true);
        $('#change').prop("",true);
        $('#reset').prop("",true);
        $('#proid').focus();
        
        }
        function validateData()
        {
            var proid,proname,proassignedto,assignmentdate,deadline;
            proid=$('#proid').val();
            proname=$('#proname').val();
            proassignedto=$('#proassignedto').val();
            assignmentdate=$('#assignmentdate').val();
            deadline=$('#deadline').val();
            if(proid==='')
            {
                alert('Project Id missing');
                $('#proid').focus();
                return;
            }
            if(proname==='')
            {
                alert('Project Name missing');
                $('#proname').focus();
                return;
            }
            if(proassignedto==='')
            {
                alert('Project assignedto missing');
                $('#proassignedto').focus();
                return;
            }
            if(assignmentdate==='')
            {
                alert('Assignment Date missing');
                $('#assignmentdate').focus();
                return;
            }
            if(deadline==='')
            {
                alert('Deadline missing');
                $('#deadline').focus();
                return;
            }
            var jsonStrObj={
                id:proid,
                name:proname,
                assignedto:proassignedto,
                assignmentdate:assignmentdate,
                deadline:deadline,
            };
            return JSON.stringify(jsonStrObj);
        }
        
        function getPro()
        {
            var proIdJsonObj=getProIdAsJsonObj();
            var getRequest=createGET_BY_KEYRequest(connToken,proDBName,proRelationName,proIdJsonObj);
            jQuery.ajaxSetup({async:false});
            var resJsonObj=executeCommandAtGivenBaseUrl(getRequest,jpdbBaseURL,jpdbIRL);
            jQuery.ajaxSetup({async:true});
            if(resJsonObj.status===400)
            {
                $('#save').prop('',false);
                $('#reset').prop('',false);
                $('#proname').focus();
            }
            elseif(resJsonObj.status===200)
            {
                $('#proid').prop('',true);
                fillData(resJsonObj);
                $('#change').prop('',false);
                $('#reset').prop('',false);
                $('#proname').focus();
                }
                }
                
                function saveData() {
var jsonStr = validateAndGetFormData();
if (jsonStr === "") {
return;
}
var putReqStr = createPUTRequest("90938336|-31949271899136568|90952433",
jsonStr, "COLLEGE-DB", "PROJECT-TABLE");
alert(putReqStr);
jQuery.ajaxSetup({async: false});
var resultObj = executeCommand(putReqStr,"http://api.login2explore.com:5577", "/api/iml");
alert(JSON.stringify(resultObj));
jQuery.ajaxSetup({async: true});
resetForm();
}
                
                function changeData()
                {
                    $('#change').prop('',true);
                    jsonChg=validateData();
                    var updateRequest=createUPDATERecordRequest(connToken,jsonChg,proDBName,proRelationName,localStorage.getItem('recno'));
                    jQuery.ajaxSetup({async:false});
            var resJsonObj=executeCommandAtGivenBaseUrl(updateRequest,jpdbBaseURL,jpdbIML);
            jQuery.ajaxSetup({async:true});
            console.log(resJsonObj);
            resetForm();
            $('#proid').focus();
                }
            
        
        

